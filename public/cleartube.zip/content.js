/* YT Loop + Shorts Hider — content script
 * - Forces the active <video> to loop, and re-applies it across YouTube's
 *   SPA navigations (so you never have to refresh).
 * - Hides Shorts everywhere (home, sidebar, search, subscriptions) and can
 *   redirect /shorts/ URLs to the normal watch player.
 * - Injects a page-context reader so the popup can list download formats.
 */
(() => {
  "use strict";

  const DEFAULTS = {
    loop: true,
    hideShorts: true,
    redirectShorts: false,
    skipSponsors: true,
    showDislikes: true,
    volumeBoost: 100,
    blockAds: true,
    speed: 1,
    ambientGlow: true,
    autoFadeUI: true,
    speedPresets: "1, 1.5, 2, 2.5, 3, 5, 10",
  };
  let settings = { ...DEFAULTS };

  /* ---------- DOWNLOAD: read player data from page context ---------- */
  let latestVideo = null; // { videoId, title, streamingData, playerUrl }

  function injectPageScript() {
    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("inject.js");
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
    } catch (_) {}
  }

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.source !== "YTLS_INJECT") return;
    latestVideo = e.data.payload;
  });

  // Popup asks the content script for the current video's formats. Ask the
  // page context to re-read window.ytInitialPlayerResponse right now first —
  // YouTube can attach higher-bitrate / Premium variants to that object
  // after the initial page load, so a live read beats the cached snapshot.
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.type === "GET_FORMATS") {
        const before = latestVideo;
        try { window.postMessage({ source: "YTLS_REQUEST_GRAB" }, "*"); } catch (_) {}
        setTimeout(() => {
          sendResponse({ video: latestVideo || before });
        }, 250);
        return true;
      }
      return false;
    });
  } catch (_) {}

  /* ---------- settings ---------- */
  function loadSettings(cb) {
    try {
      chrome.storage.sync.get(DEFAULTS, (res) => {
        settings = { ...DEFAULTS, ...res };
        cb && cb();
      });
    } catch (_) {
      cb && cb();
    }
  }

  /* ---------- LOOP ---------- */
  function applyLoop() {
    const v = document.querySelector("video");
    if (!v) return;
    if (settings.loop) {
      if (!v.loop) v.loop = true;
    } else if (v.loop) {
      v.loop = false;
    }
  }

  function watchVideo() {
    const v = document.querySelector("video");
    if (!v || v.__ytlsBound) return;
    v.__ytlsBound = true;
    v.addEventListener("ended", () => {
      if (settings.loop) {
        v.currentTime = 0;
        v.play().catch(() => {});
      }
    });
    v.addEventListener("timeupdate", () => trySkip(v));
    v.addEventListener("durationchange", renderSegmentBar);
    v.addEventListener("loadedmetadata", renderSegmentBar);
    v.addEventListener("play", () => { checkAmbientConditions(); checkAutoFadeConditions(); });
    v.addEventListener("pause", () => { checkAmbientConditions(); checkAutoFadeConditions(); });
    applyLoop();
    applySpeed();
  }

  /* ---------- SPONSOR SKIP (SponsorBlock public API) ---------- */
  const SKIP_CATEGORIES = ["sponsor", "selfpromo", "interaction"];
  let sbSegments = [];
  let sbVideoId = null;
  let sbLoading = false;
  let sbTimeSaved = 0; // total seconds skipped, persisted across sessions

  function fmtDur(s) {
    s = Math.max(0, Math.round(s));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h) return h + "h " + m + "m";
    if (m) return m + "m " + sec + "s";
    return sec + "s";
  }

  function currentVideoId() {
    try {
      const u = new URL(location.href);
      if (u.pathname === "/watch") return u.searchParams.get("v");
      const m = u.pathname.match(/^\/(?:shorts|embed)\/([\w-]+)/);
      return m ? m[1] : null;
    } catch (_) {
      return null;
    }
  }

  // Segments are fetched by the background worker (content-script fetches to
  // sponsor.ajay.app are blocked by CORS in MV3; the background bypasses it).
  async function maybeLoadSegments() {
    if (!settings.skipSponsors) {
      sbSegments = [];
      renderSegmentBar();
      return;
    }
    const vid = currentVideoId();
    if (!vid || vid === sbVideoId || sbLoading) return;
    sbVideoId = vid;
    sbLoading = true;
    sbSegments = [];
    try {
      const resp = await chrome.runtime.sendMessage({
        type: "GET_SB_SEGMENTS",
        videoId: vid,
        categories: SKIP_CATEGORIES,
      });
      if (resp && resp.ok && Array.isArray(resp.segments)) {
        sbSegments = resp.segments.sort((a, b) => a.start - b.start);
      }
    } catch (_) {}
    sbLoading = false;
    renderSegmentBar();
  }

  /* ---------- SEGMENT BAR (colored markers on the scrubber) ---------- */
  function categoryColor(cat) {
    switch (cat) {
      case "sponsor": return "#00d400";
      case "selfpromo": return "#ffff00";
      case "interaction": return "#cc00ff";
      case "intro": return "#00ffff";
      case "outro": return "#0202ed";
      case "preview": return "#008fd6";
      case "music_offtopic": return "#ff9900";
      case "filler": return "#7300ff";
      default: return "#00d400";
    }
  }

  function removeSegmentBar() {
    const o = document.getElementById("ytls-segbar");
    if (o) o.remove();
  }

  function renderSegmentBar() {
    if (!settings.skipSponsors) {
      removeSegmentBar();
      return;
    }
    const v = document.querySelector("video");
    const bar =
      document.querySelector(".ytp-progress-bar") ||
      document.querySelector(".ytp-progress-bar-container");
    if (!v || !bar || !sbSegments.length) return;
    const dur = v.duration;
    if (!dur || !isFinite(dur) || dur <= 0) return;

    let overlay = document.getElementById("ytls-segbar");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "ytls-segbar";
      overlay.style.cssText =
        "position:absolute;left:0;top:0;height:100%;width:100%;pointer-events:none;z-index:35;";
      bar.appendChild(overlay);
    }
    overlay.innerHTML = "";
    for (const seg of sbSegments) {
      const left = Math.max(0, Math.min(100, (seg.start / dur) * 100));
      const width = Math.max(0.15, Math.min(100 - left, ((seg.end - seg.start) / dur) * 100));
      const d = document.createElement("div");
      d.style.cssText =
        "position:absolute;top:0;height:100%;left:" +
        left +
        "%;width:" +
        width +
        "%;background:" +
        categoryColor(seg.cat) +
        ";opacity:.85;";
      overlay.appendChild(d);
    }
  }

  function trySkip(v) {
    if (!settings.skipSponsors || !sbSegments.length || v.paused) return;
    const t = v.currentTime;
    for (const seg of sbSegments) {
      if (t >= seg.start && t < seg.end - 0.2) {
        const saved = Math.max(0, seg.end - t);
        v.currentTime = seg.end;
        sbTimeSaved += saved;
        try {
          chrome.storage.local.set({ sbTimeSaved });
        } catch (_) {}
        sbToast(seg.cat, saved);
        break;
      }
    }
  }

  function sbToast(cat, saved) {
    try {
      const label =
        cat === "selfpromo"
          ? "self-promo"
          : cat === "interaction"
          ? "interaction reminder"
          : "sponsor";
      let el = document.getElementById("ytls-toast");
      if (!el) {
        el = document.createElement("div");
        el.id = "ytls-toast";
        el.style.cssText =
          "position:fixed;left:24px;bottom:96px;z-index:99999;" +
          "background:rgba(15,15,15,.95);color:#fff;" +
          "font-family:system-ui,-apple-system,Roboto,sans-serif;" +
          "padding:16px 22px;border-radius:14px;border-left:6px solid #ff0033;" +
          "box-shadow:0 8px 26px rgba(0,0,0,.55);transition:opacity .3s;" +
          "pointer-events:none;max-width:360px";
        document.body.appendChild(el);
      }
      el.innerHTML =
        '<div style="font-size:22px;font-weight:800;line-height:1.15">Skipped ' +
        label +
        "</div>" +
        '<div style="font-size:14px;color:#c9c9c9;margin-top:6px">+' +
        fmtDur(saved || 0) +
        " skipped &nbsp;·&nbsp; " +
        fmtDur(sbTimeSaved) +
        " saved total</div>";
      el.style.opacity = "1";
      clearTimeout(el.__t);
      el.__t = setTimeout(() => {
        el.style.opacity = "0";
      }, 3000);
    } catch (_) {}
  }

  /* ---------- BLOCK ADS (best-effort, DOM/player based) ---------- */
  const AD_STYLE_ID = "ytls-adblock-style";
  const AD_CSS = `
    #player-ads, #masthead-ad, ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer,
    ytd-banner-promo-renderer, ytd-statement-banner-renderer,
    ytd-promoted-sparkles-web-renderer, ytd-companion-slot-renderer,
    ytd-action-companion-ad-renderer, .ytp-ad-overlay-slot,
    .ytp-ad-overlay-container, #clarify-box,
    ytd-rich-item-renderer:has(ytd-ad-slot-renderer) {
      display: none !important;
    }
  `;
  function setAdStyle(on) {
    const ex = document.getElementById(AD_STYLE_ID);
    if (on) {
      if (!ex) {
        const s = document.createElement("style");
        s.id = AD_STYLE_ID;
        s.textContent = AD_CSS;
        (document.head || document.documentElement).appendChild(s);
      }
    } else if (ex) {
      ex.remove();
    }
  }
  let adActive = false;
  let priorRate = 1;

  function clickSkip() {
    // 1) Known class-based skip buttons (classic + modern).
    const sel = [
      ".ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button",
      ".ytp-skip-ad-button",
      ".ytp-ad-skip-button-container button",
      "button.ytp-ad-skip-button-modern",
      ".ytp-ad-skip-button-slot button",
    ];
    for (const s of sel) {
      const btn = document.querySelector(s);
      if (btn) {
        try {
          btn.click();
        } catch (_) {}
        return true;
      }
    }
    // 2) Text-based fallback for newer full-screen ad layouts: find a
    //    "Skip"/"Skip Ad" control inside the player, whatever its class is.
    const player =
      document.getElementById("movie_player") ||
      document.querySelector(".html5-video-player") ||
      document.querySelector("ytd-player") ||
      document.querySelector("#player");
    if (player) {
      const cands = player.querySelectorAll(
        'button, [role="button"], a, tp-yt-paper-button, yt-button-shape'
      );
      for (const b of cands) {
        const t = (b.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
        if (t === "skip" || t === "skip ad" || t === "skip ads" || /^skip\b/.test(t)) {
          try {
            b.click();
          } catch (_) {}
          return true;
        }
      }
    }
    return false;
  }

  function handleAds() {
    if (!settings.blockAds) return;
    const player =
      document.getElementById("movie_player") ||
      document.querySelector(".html5-video-player");
    const v = document.querySelector("video");
    const isAd = !!(player && player.classList.contains("ad-showing"));

    // 1) Always try to click a Skip button if one is showing.
    clickSkip();

    // 2) Close overlay/banner ads.
    const ov = document.querySelector(
      ".ytp-ad-overlay-close-button, .ytp-ad-overlay-close-container"
    );
    if (ov) {
      try {
        ov.click();
      } catch (_) {}
    }

    // 3) Ad playing → force it to finish: seek to the end, and if the ad
    //    stream isn't seekable, blast through it at max speed.
    if (isAd && v) {
      if (!adActive) {
        adActive = true;
        priorRate = v.playbackRate || 1;
      }
      try {
        if (isFinite(v.duration) && v.duration > 0) {
          v.currentTime = v.duration;
        } else if (v.playbackRate < 16) {
          v.playbackRate = 16;
        }
      } catch (_) {}
    } else if (adActive && v) {
      // Ad just ended → restore normal playback speed.
      adActive = false;
      try {
        v.playbackRate = priorRate || 1;
      } catch (_) {}
    }

    // 4) Dismiss the "ad blockers are not allowed" enforcement popup and resume.
    const enforce = document.querySelector(
      "ytd-enforcement-message-view-model, tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)"
    );
    if (enforce) {
      try {
        enforce.remove();
      } catch (_) {}
      document.querySelectorAll("tp-yt-iron-overlay-backdrop").forEach((b) => {
        try {
          b.remove();
        } catch (_) {}
      });
      if (v && v.paused) v.play().catch(() => {});
    }
  }
  let adTimer = null;

  /* ---------- VOLUME BOOST (Web Audio, up to 500%) ---------- */
  let audioCtx = null;
  function gainFor(v) {
    if (!v) return null;
    if (v.__ytlsGain) return v.__ytlsGain;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const src = audioCtx.createMediaElementSource(v);
      const g = audioCtx.createGain();
      src.connect(g);
      g.connect(audioCtx.destination);
      v.__ytlsGain = g;
      return g;
    } catch (_) {
      return null;
    }
  }
  function applyBoost() {
    const v = document.querySelector("video");
    if (!v) return;
    const boost =
      Math.max(0, Math.min(500, Number(settings.volumeBoost) || 100)) / 100;
    // Only route through Web Audio once a boost above 100% is requested, so
    // normal playback is never altered for users who don't use the booster.
    if (boost > 1 || v.__ytlsGain) {
      const g = gainFor(v);
      if (g) {
        g.gain.value = boost;
        if (audioCtx && audioCtx.state === "suspended") {
          audioCtx.resume().catch(() => {});
        }
      }
    }
  }

  /* ---------- SHOW DISLIKES (Return YouTube Dislike API) ---------- */
  let dislikeVid = null;
  let lastDislikes = null;

  function fmtCount(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, "") + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, "") + "K";
    return String(n);
  }

  async function loadDislikes() {
    if (!settings.showDislikes) return;
    const vid = currentVideoId();
    if (!vid) return;
    if (vid !== dislikeVid) {
      dislikeVid = vid;
      lastDislikes = null;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: "GET_DISLIKES",
          videoId: vid,
        });
        if (resp && resp.ok && typeof resp.dislikes === "number") {
          lastDislikes = resp.dislikes;
        }
      } catch (_) {}
    }
    injectDislikes();
  }

  function injectDislikes() {
    if (!settings.showDislikes || lastDislikes == null) return;
    const btn =
      document.querySelector("dislike-button-view-model button") ||
      document.querySelector("#segmented-dislike-button button") ||
      document.querySelector("ytd-toggle-button-renderer#dislike-button button");
    if (!btn) return;
    let span = btn.querySelector(".yt-spec-button-shape-next__button-text-content");
    if (!span) {
      span = document.createElement("div");
      span.className = "yt-spec-button-shape-next__button-text-content";
      btn.appendChild(span);
    }
    const text = fmtCount(lastDislikes);
    if (span.textContent !== text) span.textContent = text;
  }

  /* ---------- HIDE SHORTS ---------- */
  const STYLE_ID = "ytls-hide-shorts-style";
  const HIDE_CSS = `
    ytd-rich-shelf-renderer[is-shorts],
    ytd-reel-shelf-renderer,
    grid-shelf-view-model,
    ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]),
    ytd-rich-section-renderer:has([overlay-style="SHORTS"]),
    ytd-guide-entry-renderer:has(a[title="Shorts"]),
    ytd-mini-guide-entry-renderer[aria-label="Shorts"],
    a#endpoint[title="Shorts"],
    ytd-video-renderer:has(a[href^="/shorts"]),
    ytd-grid-video-renderer:has(a[href^="/shorts"]),
    ytd-rich-item-renderer:has(a[href^="/shorts"]),
    ytm-shorts-lockup-view-model,
    yt-chip-cloud-chip-renderer:has(yt-formatted-string[title="Shorts"]) {
      display: none !important;
    }
  `;

  function setShortsHidden(on) {
    const existing = document.getElementById(STYLE_ID);
    if (on) {
      if (!existing) {
        const style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = HIDE_CSS;
        (document.head || document.documentElement).appendChild(style);
      }
    } else if (existing) {
      existing.remove();
    }
  }

  function maybeRedirectShorts() {
    if (!settings.hideShorts || !settings.redirectShorts) return;
    const m = location.pathname.match(/^\/shorts\/([\w-]+)/);
    if (m) {
      location.replace("https://www.youtube.com/watch?v=" + m[1]);
    }
  }

  /* ---------- apply everything ---------- */
  /* ---------- PLAYBACK SPEED (Customizable presets) ---------- */
  const SPEED_MIN = 0.25;

  function parseSpeedPresets(str) {
    const raw = (str || "1, 1.5, 2, 2.5, 3, 5, 10").split(/[\s,]+/);
    const parsed = raw.map(Number).filter((n) => !isNaN(n) && n >= 0.1 && n <= 100);
    const set = Array.from(new Set(parsed)).sort((a, b) => a - b);
    return set.length ? set : [1, 1.5, 2, 2.5, 3, 5, 10];
  }

  function getSpeedSnapPoints() {
    const presets = parseSpeedPresets(settings.speedPresets);
    const base = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.5, 4, 5, 10, 16, 20, 50, 100];
    return Array.from(new Set([...base, ...presets])).sort((a, b) => a - b);
  }

  function getSpeedMax() {
    const presets = parseSpeedPresets(settings.speedPresets);
    const maxPreset = Math.max(...presets, 10);
    return Math.min(100, Math.max(maxPreset, Number(settings.speed) || 1));
  }

  let turboTimer = null;

  function applySpeed() {
    const v = document.querySelector("video");
    if (!v) return;
    const max = getSpeedMax();
    const s = Math.max(SPEED_MIN, Math.min(max, Number(settings.speed) || 1));
    // Browsers clamp playbackRate at 16x, so above that we nudge currentTime
    // forward on a timer ("turbo") to reach the requested speed.
    try {
      v.playbackRate = Math.min(16, s);
    } catch (_) {}
    if (s > 16) startTurbo(s);
    else stopTurbo();
  }
  function startTurbo(s) {
    stopTurbo();
    turboTimer = setInterval(() => {
      const v = document.querySelector("video");
      if (!v || v.paused) return;
      const p = document.getElementById("movie_player");
      if (p && p.classList.contains("ad-showing")) return;
      try {
        v.currentTime += (s - 16) * 0.1; // 16x from playbackRate + the remainder
      } catch (_) {}
    }, 100);
  }
  function stopTurbo() {
    if (turboTimer) {
      clearInterval(turboTimer);
      turboTimer = null;
    }
  }
  function setSpeed(s, persist) {
    settings.speed = s;
    if (persist !== false) {
      try {
        chrome.storage.sync.set({ speed: s });
      } catch (_) {}
    }
    applySpeed();
  }
  function setVolumeBoost(v, persist) {
    settings.volumeBoost = v;
    if (persist !== false) {
      try {
        chrome.storage.sync.set({ volumeBoost: v });
      } catch (_) {}
    }
    applyBoost();
  }
  function fmtSpeed(s) {
    return (Math.abs(s - Math.round(s)) < 0.001 ? Math.round(s) : Math.round(s * 100) / 100) + "×";
  }

  /* ---------- speed slider: logarithmic position with magnetic snap points ---------- */
  const SLIDER_STEPS = 1000;
  function speedToPos(s) {
    const max = getSpeedMax();
    const c = Math.max(SPEED_MIN, Math.min(max, s));
    return Math.round((SLIDER_STEPS * Math.log(c / SPEED_MIN)) / Math.log(max / SPEED_MIN));
  }
  function posToSpeed(pos) {
    const max = getSpeedMax();
    return SPEED_MIN * Math.pow(max / SPEED_MIN, pos / SLIDER_STEPS);
  }
  function niceRound(s) {
    if (s < 1) return Math.round(s * 20) / 20; // nearest 0.05
    if (s < 10) return Math.round(s * 10) / 10; // nearest 0.1
    return Math.round(s); // nearest 1
  }
  function magnetize(s) {
    let best = null,
      bestDist = Infinity;
    const snapPoints = getSpeedSnapPoints();
    for (const p of snapPoints) {
      const dist = Math.abs(Math.log(s / p));
      if (dist < bestDist) {
        bestDist = dist;
        best = p;
      }
    }
    return bestDist < 0.06 ? best : niceRound(s);
  }
  function ensureSpeedSliderStyle() {
    if (document.getElementById("ct-speed-style")) return;
    const style = document.createElement("style");
    style.id = "ct-speed-style";
    style.textContent =
      "#ct-speed-slider,#ct-vol-slider{-webkit-appearance:none;appearance:none;width:" + SPEED_TRACK_WIDTH + "px;height:6px;border-radius:999px;" +
      "background:rgba(128,128,128,0.35);outline:none;vertical-align:middle;margin:0;}" +
      "#ct-vol-slider{width:130px;}" +
      "#ct-speed-slider::-webkit-slider-thumb,#ct-vol-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:14px;height:14px;" +
      "border-radius:50%;background:#ff5277;border:2px solid #fff;cursor:pointer;margin-top:-4px;" +
      "box-shadow:0 1px 3px rgba(0,0,0,.4);}" +
      "#ct-speed-slider::-moz-range-thumb,#ct-vol-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:#ff5277;" +
      "border:2px solid #fff;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.4);}" +
      "#ct-speed-slider::-moz-range-track,#ct-vol-slider::-moz-range-track{height:6px;border-radius:999px;background:rgba(128,128,128,0.35);}" +
      "#ct-speed-pips{position:relative;width:" + SPEED_TRACK_WIDTH + "px;height:4px;margin:2px 0 4px 0;pointer-events:none;}" +
      ".ct-speed-pip{position:absolute;top:0;width:2px;height:4px;background:rgba(255,255,255,0.3);border-radius:1px;transform:translateX(-50%);}" +
      "#ct-speed-btn-row{display:flex;flex-wrap:wrap;align-items:center;gap:6px;max-width:440px;margin-top:2px;}" +
      ".ct-speed-pill{display:inline-flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.16);" +
      "color:#ccc;border-radius:6px;padding:3px 8px;font:600 11px Roboto,system-ui,sans-serif;cursor:pointer;line-height:1.2;" +
      "transition:all 0.15s ease;user-select:none;white-space:nowrap;}" +
      ".ct-speed-pill:hover{background:rgba(255,82,119,0.22);border-color:#ff5277;color:#fff;transform:translateY(-1px);}" +
      ".ct-speed-pill.active{background:#ff5277 !important;border-color:#ff5277 !important;color:#fff !important;font-weight:700 !important;" +
      "box-shadow:0 1px 8px rgba(255,82,119,0.45);}" +
      "#ct-speed-edit-btn{display:inline-flex;align-items:center;gap:3px;background:rgba(255,82,119,0.12);color:#ff6f8b;" +
      "border:1px solid rgba(255,82,119,0.35);border-radius:6px;padding:2px 7px;font:600 11px Roboto,system-ui,sans-serif;" +
      "cursor:pointer;line-height:1.2;transition:all 0.15s ease;user-select:none;margin-left:2px;}" +
      "#ct-speed-edit-btn:hover{background:rgba(255,82,119,0.25);border-color:#ff5277;color:#fff;box-shadow:0 0 8px rgba(255,82,119,0.35);}" +
      "#ct-speed-edit-btn.active{background:#ff5277;color:#fff;border-color:#ff5277;}" +
      "#ct-speed-popover{position:absolute;top:calc(100% + 8px);left:0;z-index:9999999;width:390px;max-width:92vw;" +
      "background:#111015;border:1px solid rgba(255,82,119,0.4);border-radius:12px;padding:14px 16px;" +
      "box-shadow:0 16px 40px rgba(0,0,0,0.85),0 0 25px rgba(255,82,119,0.15);color:#f1f1f1;font-family:Roboto,system-ui,sans-serif;box-sizing:border-box;}" +
      "#ct-speed-popover *{box-sizing:border-box;}" +
      ".ct-pop-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.08);}" +
      ".ct-pop-title{font-size:13px;font-weight:700;color:#fff;display:flex;align-items:center;gap:6px;}" +
      ".ct-pop-tag{font-size:9.5px;font-weight:700;background:rgba(255,82,119,0.2);color:#ff6f8b;padding:1px 6px;border-radius:999px;letter-spacing:0.5px;text-transform:uppercase;}" +
      ".ct-pop-close{background:transparent;border:none;color:#888;font-size:16px;line-height:1;cursor:pointer;padding:2px 6px;border-radius:4px;}" +
      ".ct-pop-close:hover{color:#fff;background:rgba(255,255,255,0.1);}" +
      ".ct-pop-sec-title{font-size:11px;font-weight:600;color:#aaa;margin:9px 0 5px 0;text-transform:uppercase;letter-spacing:0.5px;}" +
      ".ct-pop-packs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;}" +
      ".ct-pop-pack-btn{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.14);color:#ccc;border-radius:6px;padding:4px 9px;font-size:11px;font-weight:500;cursor:pointer;transition:all 0.15s ease;}" +
      ".ct-pop-pack-btn:hover{background:rgba(255,82,119,0.15);border-color:#ff5277;color:#ff8fa3;}" +
      ".ct-pop-chips-grid{display:flex;flex-wrap:wrap;gap:6px;max-height:120px;overflow-y:auto;padding:3px;margin-bottom:10px;}" +
      ".ct-pop-chips-grid::-webkit-scrollbar{width:4px;}" +
      ".ct-pop-chips-grid::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.2);border-radius:4px;}" +
      ".ct-pop-chip{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.14);color:#aaa;border-radius:6px;padding:4px 8px;font-size:11px;font-weight:600;min-width:44px;text-align:center;cursor:pointer;user-select:none;transition:all 0.15s ease;}" +
      ".ct-pop-chip:hover{border-color:rgba(255,82,119,0.5);color:#fff;}" +
      ".ct-pop-chip.active{background:#ff5277 !important;border-color:#ff5277 !important;color:#fff !important;font-weight:700;box-shadow:0 2px 8px rgba(255,82,119,0.4);}" +
      ".ct-pop-input-row{display:flex;gap:6px;margin-bottom:10px;}" +
      ".ct-pop-input{flex:1;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.18);border-radius:6px;padding:7px 10px;color:#fff;font:500 12px Roboto,monospace,sans-serif;outline:none;}" +
      ".ct-pop-input:focus{border-color:#ff5277;box-shadow:0 0 0 2px rgba(255,82,119,0.25);}" +
      ".ct-pop-actions{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,0.08);gap:8px;}" +
      ".ct-pop-save-btn{background:#ff5277;color:#fff;border:none;border-radius:6px;padding:7px 16px;font:700 12px Roboto,system-ui,sans-serif;cursor:pointer;transition:background 0.15s ease;}" +
      ".ct-pop-save-btn:hover{background:#ff3360;}" +
      ".ct-pop-reset-btn{background:transparent;border:1px solid rgba(255,255,255,0.15);color:#aaa;border-radius:6px;padding:6px 12px;font:500 11px Roboto,system-ui,sans-serif;cursor:pointer;}" +
      ".ct-pop-reset-btn:hover{color:#fff;border-color:rgba(255,255,255,0.3);}" +
      ".ct-pop-saved-msg{color:#4ade80;font-size:11px;font-weight:600;display:none;}";
    document.head.appendChild(style);
  }
  const SPEED_TRACK_WIDTH = 300;

  /* ---------- ON-PAGE CONTROL BAR (below the video) ---------- */
  function barBtn(text, active, onClick, title) {
    const b = document.createElement("button");
    b.textContent = text;
    if (title) b.title = title;
    b.style.cssText =
      "font:600 12px Roboto,system-ui,sans-serif;cursor:pointer;border-radius:8px;padding:6px 10px;line-height:1;" +
      "border:1px solid " +
      (active ? "#ff5277" : "rgba(128,128,128,0.35)") +
      ";background:" +
      (active ? "rgba(255,82,119,0.16)" : "transparent") +
      ";color:" +
      (active ? "#ff6f8b" : "var(--yt-spec-text-primary, #f1f1f1)") +
      ";";
    b.addEventListener("click", (e) => {
      e.preventDefault();
      onClick();
    });
    return b;
  }
  function toggleSetting(key) {
    settings[key] = !settings[key];
    try {
      chrome.storage.sync.set({ [key]: settings[key] });
    } catch (_) {}
    applyAll();
  }
  function removeBar() {
    const b = document.getElementById("ct-bar");
    if (b) b.remove();
  }
  function buildBar() {
    if (location.pathname !== "/watch" || !currentVideoId()) {
      removeBar();
      return;
    }
    let bar = document.getElementById("ct-bar");
    if (!bar) {
      const mount =
        document.querySelector("#below") ||
        document.querySelector("ytd-watch-metadata");
      if (!mount) return;
      bar = document.createElement("div");
      bar.id = "ct-bar";
      bar.style.cssText =
        "display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:12px 0;padding:10px 12px;" +
        "border:1px solid var(--yt-spec-10-percent-layer, rgba(128,128,128,0.2));border-radius:12px;" +
        "background:var(--yt-spec-badge-chip-background, rgba(128,128,128,0.08));position:relative;z-index:999;";
      mount.prepend(bar);
    }
    updateBar();
  }
  function updateBar() {
    const bar = document.getElementById("ct-bar");
    if (!bar) return;
    bar.textContent = "";

    const brand = document.createElement("span");
    brand.textContent = "ClearTube";
    brand.style.cssText = "font:700 12px Roboto,system-ui,sans-serif;color:#ff5277;";
    bar.appendChild(brand);

    const spLabel = document.createElement("span");
    spLabel.textContent = "Speed";
    spLabel.style.cssText =
      "font:600 12px Roboto,system-ui,sans-serif;color:var(--yt-spec-text-secondary,#aaa);margin-left:6px;";
    bar.appendChild(spLabel);

    ensureSpeedSliderStyle();
    const cur = Math.max(SPEED_MIN, Math.min(getSpeedMax(), Number(settings.speed) || 1));

    const sliderCol = document.createElement("span");
    sliderCol.style.cssText = "display:inline-flex;flex-direction:column;gap:1px;position:relative;";

    const sliderRow = document.createElement("span");
    sliderRow.style.cssText = "display:inline-flex;align-items:center;gap:8px;";

    const valueLabel = document.createElement("span");
    valueLabel.textContent = fmtSpeed(cur);
    valueLabel.style.cssText =
      "font:700 12px Roboto,system-ui,sans-serif;color:#ff5277;min-width:44px;";

    const slider = document.createElement("input");
    slider.type = "range";
    slider.id = "ct-speed-slider";
    slider.min = "0";
    slider.max = String(SLIDER_STEPS);
    slider.step = "1";
    slider.value = String(speedToPos(cur));
    slider.title = "Drag to set playback speed";

    const customPresets = parseSpeedPresets(settings.speedPresets);

    const btnRow = document.createElement("div");
    btnRow.id = "ct-speed-btn-row";

    function highlightActivePill(val) {
      btnRow.querySelectorAll(".ct-speed-pill").forEach((pill) => {
        const s = Number(pill.dataset.speed);
        if (Math.abs(s - val) < 0.01) {
          pill.classList.add("active");
        } else {
          pill.classList.remove("active");
        }
      });
    }

    slider.addEventListener("input", () => {
      const raw = posToSpeed(Number(slider.value));
      const snapped = magnetize(raw);
      const snappedPos = speedToPos(snapped);
      // Only visually "stick" the thumb when it's genuinely close to a tick —
      // otherwise free dragging would feel jumpy.
      if (Math.abs(snappedPos - Number(slider.value)) <= 15) {
        slider.value = String(snappedPos);
      }
      valueLabel.textContent = fmtSpeed(snapped);
      setSpeed(snapped, false); // live preview, no storage write yet
      highlightActivePill(snapped);
    });
    slider.addEventListener("change", () => {
      const snapped = magnetize(posToSpeed(Number(slider.value)));
      setSpeed(snapped, true);
      highlightActivePill(snapped);
    });

    // Inline Edit Button on the slider itself
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.id = "ct-speed-edit-btn";
    editBtn.innerHTML = "⚙ Edit";
    editBtn.title = "Configure speed presets & custom values";

    sliderRow.appendChild(slider);
    sliderRow.appendChild(valueLabel);
    sliderRow.appendChild(editBtn);

    // Track pips indicating exact magnetic snap points
    const trackPips = document.createElement("div");
    trackPips.id = "ct-speed-pips";

    customPresets.forEach((p) => {
      const x = (speedToPos(p) / SLIDER_STEPS) * SPEED_TRACK_WIDTH;
      const pip = document.createElement("span");
      pip.className = "ct-speed-pip";
      pip.style.left = Math.min(SPEED_TRACK_WIDTH - 2, Math.max(1, x)) + "px";
      trackPips.appendChild(pip);

      // Clean clickable pill button with even spacing
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ct-speed-pill" + (Math.abs(cur - p) < 0.01 ? " active" : "");
      btn.dataset.speed = String(p);
      btn.textContent = (p < 1 ? p : (Math.abs(p - Math.round(p)) < 0.01 ? Math.round(p) : p)) + "×";
      btn.title = "Set speed to " + p + "×";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        slider.value = String(speedToPos(p));
        valueLabel.textContent = fmtSpeed(p);
        setSpeed(p, true);
        highlightActivePill(p);
      });
      btnRow.appendChild(btn);
    });

    sliderCol.appendChild(sliderRow);
    sliderCol.appendChild(trackPips);
    sliderCol.appendChild(btnRow);
    bar.appendChild(sliderCol);

    // Interactive Popover for choosing each value and writing custom ones
    let popover = null;
    let onDocClick = null;

    function closePopover() {
      if (popover) {
        popover.remove();
        popover = null;
        editBtn.classList.remove("active");
        if (onDocClick) {
          document.removeEventListener("pointerdown", onDocClick);
          onDocClick = null;
        }
      }
    }

    function togglePopover() {
      if (popover) {
        closePopover();
        return;
      }

      editBtn.classList.add("active");
      popover = document.createElement("div");
      popover.id = "ct-speed-popover";

      // Prevent events inside popover from bubbling or triggering YouTube shortcuts
      popover.addEventListener("click", (e) => e.stopPropagation());
      popover.addEventListener("keydown", (e) => e.stopPropagation());
      popover.addEventListener("keyup", (e) => e.stopPropagation());
      popover.addEventListener("keypress", (e) => e.stopPropagation());

      // Header
      const head = document.createElement("div");
      head.className = "ct-pop-head";
      head.innerHTML =
        '<div class="ct-pop-title">Speed Presets <span class="ct-pop-tag">Custom</span></div>' +
        '<button type="button" class="ct-pop-close" title="Close">✕</button>';
      head.querySelector(".ct-pop-close").addEventListener("click", closePopover);
      popover.appendChild(head);

      // Section 1: Quick Profiles
      const packTitle = document.createElement("div");
      packTitle.className = "ct-pop-sec-title";
      packTitle.textContent = "Quick Profiles:";
      popover.appendChild(packTitle);

      const packsContainer = document.createElement("div");
      packsContainer.className = "ct-pop-packs";

      const PACKS = [
        { name: "Default (1–10×)", val: "1, 1.5, 2, 2.5, 3, 5, 10" },
        { name: "Casual (0.75–2×)", val: "0.75, 1, 1.25, 1.5, 1.75, 2" },
        { name: "Fine (0.25 steps)", val: "0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5" },
        { name: "Study (1–3×)", val: "1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 3" },
        { name: "Ultra (up to 100×)", val: "1, 2, 5, 10, 20, 50, 100" }
      ];

      // Section 2: Choose Each Value (Chips Grid)
      const chipTitle = document.createElement("div");
      chipTitle.className = "ct-pop-sec-title";
      chipTitle.textContent = "Choose Values (click to toggle):";

      const chipsGrid = document.createElement("div");
      chipsGrid.className = "ct-pop-chips-grid";

      const SPEED_CHOICES = [
        0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 4, 5, 6, 8, 10, 12, 16, 20, 50, 100
      ];

      // Section 3: Custom Text Input
      const inputTitle = document.createElement("div");
      inputTitle.className = "ct-pop-sec-title";
      inputTitle.textContent = "Custom speeds (comma-separated):";

      const inputRow = document.createElement("div");
      inputRow.className = "ct-pop-input-row";

      const input = document.createElement("input");
      input.type = "text";
      input.className = "ct-pop-input";
      input.placeholder = "e.g. 1, 1.5, 2, 2.5, 3.5, 5, 10";
      input.value = settings.speedPresets || "1, 1.5, 2, 2.5, 3, 5, 10";
      inputRow.appendChild(input);

      function syncChipsFromInput() {
        const currentVals = parseSpeedPresets(input.value);
        chipsGrid.querySelectorAll(".ct-pop-chip").forEach((chip) => {
          const val = Number(chip.dataset.val);
          if (currentVals.includes(val)) {
            chip.classList.add("active");
          } else {
            chip.classList.remove("active");
          }
        });
      }

      SPEED_CHOICES.forEach((spd) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "ct-pop-chip";
        chip.dataset.val = String(spd);
        chip.textContent = spd + "×";
        chip.addEventListener("click", () => {
          let list = parseSpeedPresets(input.value);
          if (list.includes(spd)) {
            if (list.length > 1) {
              list = list.filter((x) => x !== spd);
            }
          } else {
            list.push(spd);
          }
          list.sort((a, b) => a - b);
          input.value = list.join(", ");
          syncChipsFromInput();
        });
        chipsGrid.appendChild(chip);
      });

      PACKS.forEach((p) => {
        const pBtn = document.createElement("button");
        pBtn.type = "button";
        pBtn.className = "ct-pop-pack-btn";
        pBtn.textContent = p.name;
        pBtn.addEventListener("click", () => {
          input.value = p.val;
          syncChipsFromInput();
        });
        packsContainer.appendChild(pBtn);
      });

      input.addEventListener("input", syncChipsFromInput);

      // Section 4: Actions
      const actions = document.createElement("div");
      actions.className = "ct-pop-actions";

      const resetBtn = document.createElement("button");
      resetBtn.type = "button";
      resetBtn.className = "ct-pop-reset-btn";
      resetBtn.textContent = "Reset Default";
      resetBtn.addEventListener("click", () => {
        input.value = "1, 1.5, 2, 2.5, 3, 5, 10";
        syncChipsFromInput();
      });

      const savedMsg = document.createElement("span");
      savedMsg.className = "ct-pop-saved-msg";
      savedMsg.textContent = "✓ Applied!";

      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "ct-pop-save-btn";
      saveBtn.textContent = "Save & Apply";

      function doSave() {
        const parsed = parseSpeedPresets(input.value);
        const formatted = parsed.join(", ");
        settings.speedPresets = formatted;
        try {
          chrome.storage.sync.set({ speedPresets: formatted });
        } catch (_) {}
        savedMsg.style.display = "inline";
        setTimeout(() => {
          closePopover();
          updateBar();
          applySpeed();
        }, 250);
      }

      saveBtn.addEventListener("click", doSave);
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          doSave();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closePopover();
        }
      });

      actions.appendChild(resetBtn);
      actions.appendChild(savedMsg);
      actions.appendChild(saveBtn);

      popover.appendChild(packsContainer);
      popover.appendChild(chipTitle);
      popover.appendChild(chipsGrid);
      popover.appendChild(inputTitle);
      popover.appendChild(inputRow);
      popover.appendChild(actions);

      sliderCol.appendChild(popover);
      syncChipsFromInput();
      setTimeout(() => input.focus(), 50);

      onDocClick = (e) => {
        if (popover && !popover.contains(e.target) && e.target !== editBtn) {
          closePopover();
        }
      };
      document.addEventListener("pointerdown", onDocClick);
    }

    editBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      togglePopover();
    });

    const divider = document.createElement("span");
    divider.style.cssText =
      "width:1px;height:20px;background:rgba(128,128,128,0.35);margin:0 4px;";
    bar.appendChild(divider);

    const volLabel = document.createElement("span");
    volLabel.textContent = "Volume";
    volLabel.style.cssText =
      "font:600 12px Roboto,system-ui,sans-serif;color:var(--yt-spec-text-secondary,#aaa);";
    bar.appendChild(volLabel);

    const curVol = Math.max(100, Math.min(500, Number(settings.volumeBoost) || 100));
    const volValueLabel = document.createElement("span");
    volValueLabel.textContent = curVol + "%";
    volValueLabel.style.cssText =
      "font:700 12px Roboto,system-ui,sans-serif;color:#ff5277;min-width:38px;";

    const volSlider = document.createElement("input");
    volSlider.type = "range";
    volSlider.id = "ct-vol-slider";
    volSlider.min = "100";
    volSlider.max = "500";
    volSlider.step = "10";
    volSlider.value = String(curVol);
    volSlider.title = "Volume boost (100%–500%)";
    volSlider.addEventListener("input", () => {
      const v = Number(volSlider.value);
      volValueLabel.textContent = v + "%";
      setVolumeBoost(v, false);
    });
    volSlider.addEventListener("change", () => {
      setVolumeBoost(Number(volSlider.value), true);
    });
    bar.appendChild(volSlider);
    bar.appendChild(volValueLabel);

    const divider2 = document.createElement("span");
    divider2.style.cssText =
      "width:1px;height:20px;background:rgba(128,128,128,0.35);margin:0 4px;";
    bar.appendChild(divider2);

    bar.appendChild(barBtn("Loop", !!settings.loop, () => toggleSetting("loop")));
    bar.appendChild(barBtn("Skip sponsors", !!settings.skipSponsors, () => toggleSetting("skipSponsors")));
    bar.appendChild(barBtn("Block ads", !!settings.blockAds, () => toggleSetting("blockAds")));
    bar.appendChild(barBtn("Hide Shorts", !!settings.hideShorts, () => toggleSetting("hideShorts")));

    bar.appendChild(
      barBtn("⤓ Download", false, () => {
        const vid = currentVideoId();
        if (!vid) return;
        try {
          navigator.clipboard.writeText("https://www.youtube.com/watch?v=" + vid);
        } catch (_) {}
        window.open("https://ytmp3.ws/nie/", "_blank");
      }, "Copy link & open downloader")
    );
  }

  /* ---------- AMBIENT GLOW (dynamic video color behind/around player) ---------- */
  const AMBIENT_STYLE_ID = "ct-ambient-style";
  const AMBIENT_CSS = `
    /* Eliminate section lines and borders in theater mode for 1 seamless backdrop */
    ytd-watch-flexy[theater] #masthead-container,
    ytd-watch-grid[theater] #masthead-container,
    ytd-watch-flexy[theater] #masthead,
    ytd-watch-grid[theater] #masthead,
    ytd-watch-flexy[theater] #player-theater-container,
    ytd-watch-grid[theater] #player-theater-container,
    ytd-watch-flexy[theater] #full-bleed-container,
    ytd-watch-flexy[theater] #player-container-outer,
    ytd-watch-flexy[theater] #player-container,
    ytd-watch-flexy[theater] #below,
    ytd-watch-flexy[theater] #primary,
    ytd-watch-flexy[theater] #secondary,
    ytd-watch-flexy[theater] #columns {
      border: none !important;
      border-top: none !important;
      border-bottom: none !important;
      border-left: none !important;
      border-right: none !important;
      box-shadow: none !important;
      outline: none !important;
    }

    ytd-watch-flexy[theater] #player-theater-container,
    ytd-watch-flexy[theater] #full-bleed-container,
    ytd-watch-grid[theater] #player-theater-container {
      background: #09090b !important;
      overflow: visible !important;
    }

    /* Video player crisp modern border & subtle rounding in theater mode */
    ytd-watch-flexy[theater] #movie_player,
    ytd-watch-grid[theater] #movie_player {
      border-radius: 14px !important;
      border: 1.5px solid rgba(255, 255, 255, 0.22) !important;
      box-shadow: 0 16px 48px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(255, 255, 255, 0.08) !important;
      overflow: hidden !important;
      position: relative !important;
      z-index: 2 !important;
      transition: border-color 0.35s ease, box-shadow 0.35s ease !important;
    }
    ytd-watch-flexy[theater] #movie_player video.html5-main-video,
    ytd-watch-grid[theater] #movie_player video.html5-main-video {
      border-radius: 12px !important;
    }

    /* Ambient glow halo behind the player */
    #ct-ambient-glow {
      position: absolute;
      inset: -50px -70px;
      z-index: 1;
      pointer-events: none;
      border-radius: 36px;
      filter: blur(75px);
      opacity: 0.85;
      transition: background 0.4s ease, box-shadow 0.4s ease, opacity 0.4s ease;
    }

    #full-bleed-container,
    #player-theater-container,
    #player-container-outer,
    #player-container-inner,
    ytd-watch-flexy[theater] #player-container,
    ytd-watch-grid[theater] #player-container {
      overflow: visible !important;
    }
  `;
  let ambientRaf = null;
  let ambientCanvas = null;
  let ambientCtx = null;
  let ambientLastSample = 0;
  let ambientActive = false;
  const ambientReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

  function isTheaterMode() {
    if (location.pathname !== "/watch") return false;
    const flexy = document.querySelector("ytd-watch-flexy, ytd-watch-grid");
    if (flexy) {
      if (flexy.hasAttribute("theater") || flexy.hasAttribute("theater-requested_")) {
        return !flexy.hasAttribute("fullscreen");
      }
    }
    const tc = document.getElementById("player-theater-container");
    if (tc && tc.offsetHeight > 100) return true;
    const player = document.getElementById("movie_player");
    if (player && player.classList.contains("ytp-big-mode") && !document.fullscreenElement) {
      return true;
    }
    return false;
  }

  function ensureAmbientStyle() {
    if (document.getElementById(AMBIENT_STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = AMBIENT_STYLE_ID;
    s.textContent = AMBIENT_CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  function startAmbientGlow() {
    if (ambientActive) return;
    ambientActive = true;
    ensureAmbientStyle();
    if (!ambientCanvas) {
      ambientCanvas = document.createElement("canvas");
      ambientCanvas.width = 16;
      ambientCanvas.height = 9;
      ambientCtx = ambientCanvas.getContext("2d", { willReadFrequently: true });
    }
    ensureGlowElement();
    ambientLastSample = 0;
    ambientRaf = requestAnimationFrame(ambientFrame);
  }

  function ensureGlowElement() {
    const player = document.getElementById("movie_player") || document.querySelector(".html5-video-player");
    if (!player || !player.parentElement) return null;

    let glow = document.getElementById("ct-ambient-glow");
    if (!glow) {
      glow = document.createElement("div");
      glow.id = "ct-ambient-glow";
      player.parentElement.style.position = "relative";
      player.parentElement.style.overflow = "visible";
      player.parentElement.insertBefore(glow, player);
    }
    return glow;
  }

  function stopAmbientGlow() {
    if (!ambientActive) return;
    ambientActive = false;
    if (ambientRaf) {
      cancelAnimationFrame(ambientRaf);
      ambientRaf = null;
    }
    const glow = document.getElementById("ct-ambient-glow");
    if (glow) glow.remove();
    const player = document.getElementById("movie_player");
    if (player) {
      player.style.boxShadow = "";
      player.style.borderColor = "";
    }
  }

  function ambientFrame(ts) {
    if (!ambientActive) return;
    // Sample every ~120ms for smooth 8-9fps color transitions with zero frame drops
    if (ts - ambientLastSample >= 120) {
      ambientLastSample = ts;
      const v = document.querySelector("video");
      const player = document.getElementById("movie_player") || document.querySelector(".html5-video-player");
      const glow = ensureGlowElement();

      if (v && v.readyState >= 2 && !v.paused && v.videoWidth > 0) {
        try {
          ambientCtx.drawImage(v, 0, 0, 16, 9);
          const imgData = ambientCtx.getImageData(0, 0, 16, 9).data;
          let rTotal = 0, gTotal = 0, bTotal = 0, count = 0;
          for (let i = 0; i < imgData.length; i += 4) {
            rTotal += imgData[i];
            gTotal += imgData[i + 1];
            bTotal += imgData[i + 2];
            count++;
          }
          let r = Math.round(rTotal / count);
          let g = Math.round(gTotal / count);
          let b = Math.round(bTotal / count);

          // Boost color vibrancy so the ambient light is vivid
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          if (max > min && max > 20) {
            const boost = 1.35;
            r = Math.min(255, Math.round(r * boost));
            g = Math.min(255, Math.round(g * boost));
            b = Math.min(255, Math.round(b * boost));
          }

          const shadow =
            "0 0 100px 40px rgba(" + r + "," + g + "," + b + ",0.50), " +
            "0 0 200px 90px rgba(" + r + "," + g + "," + b + ",0.25)";

          if (glow) {
            glow.style.background = "radial-gradient(ellipse at center, rgba(" + r + "," + g + "," + b + ",0.70) 0%, rgba(" + r + "," + g + "," + b + ",0.25) 50%, transparent 85%)";
            glow.style.boxShadow = shadow;
          }
          if (player) {
            player.style.boxShadow = "0 16px 48px rgba(0,0,0,0.9), 0 0 50px 15px rgba(" + r + "," + g + "," + b + ",0.40)";
            player.style.borderColor = "rgba(" + Math.min(255, r + 40) + "," + Math.min(255, g + 40) + "," + Math.min(255, b + 40) + ",0.35)";
          }
        } catch (_) {
          // Keep loop alive across transient canvas read issues
        }
      }
    }
    ambientRaf = requestAnimationFrame(ambientFrame);
  }

  function checkAmbientConditions() {
    const isWatch = location.pathname === "/watch";
    const v = document.querySelector("video");
    const playing = v && !v.paused && !v.ended;
    const shouldRun =
      settings.ambientGlow &&
      isWatch &&
      !document.hidden &&
      playing;

    if (shouldRun) {
      startAmbientGlow();
    } else {
      stopAmbientGlow();
    }
  }

  /* ---------- AUTO-FADE UI (hide page chrome on idle in theater mode) ---------- */
  const FADE_STYLE_ID = "ct-fade-style";
  const FADE_CSS = `
    body.clearline-idle {
      overflow: hidden !important;
    }
    body.clearline-idle::-webkit-scrollbar,
    body.clearline-idle *::-webkit-scrollbar {
      display: none !important;
      width: 0 !important;
    }
    body.clearline-idle #below,
    body.clearline-idle #ct-bar,
    body.clearline-idle #secondary,
    body.clearline-idle #related,
    body.clearline-idle #comments,
    body.clearline-idle ytd-watch-metadata,
    body.clearline-idle #masthead-container,
    body.clearline-idle #chat,
    body.clearline-idle #ticket-shelf {
      opacity: 0 !important;
      pointer-events: none !important;
      visibility: hidden !important;
      transition: opacity 0.45s ease, visibility 0.45s ease !important;
    }
    #below,
    #ct-bar,
    #secondary,
    #related,
    #comments,
    ytd-watch-metadata,
    #masthead-container,
    #chat {
      transition: opacity 0.35s ease, visibility 0.35s ease;
    }
  `;
  const IDLE_TIMEOUT = 2500;
  let fadeActive = false;
  let fadeTimer = null;

  function ensureFadeStyle() {
    if (document.getElementById(FADE_STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = FADE_STYLE_ID;
    s.textContent = FADE_CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  function setIdle(on) {
    document.body.classList.toggle("clearline-idle", on);
  }

  function resetIdleTimer() {
    setIdle(false);
    clearTimeout(fadeTimer);
    const v = document.querySelector("video");
    if (fadeActive && v && !v.paused && !v.ended) {
      fadeTimer = setTimeout(() => {
        if (document.getElementById("ct-speed-popover")) {
          resetIdleTimer();
          return;
        }
        const curV = document.querySelector("video");
        if (fadeActive && curV && !curV.paused) {
          setIdle(true);
        }
      }, IDLE_TIMEOUT);
    }
  }

  function onFadeActivity() {
    if (fadeActive) resetIdleTimer();
  }

  function startAutoFade() {
    if (fadeActive) return;
    fadeActive = true;
    ensureFadeStyle();
    window.addEventListener("mousemove", onFadeActivity, { capture: true, passive: true });
    window.addEventListener("mousedown", onFadeActivity, { capture: true, passive: true });
    window.addEventListener("keydown", onFadeActivity, { capture: true, passive: true });
    window.addEventListener("wheel", onFadeActivity, { capture: true, passive: true });
    window.addEventListener("touchstart", onFadeActivity, { capture: true, passive: true });
    resetIdleTimer();
  }

  function stopAutoFade() {
    if (!fadeActive) return;
    fadeActive = false;
    clearTimeout(fadeTimer);
    fadeTimer = null;
    setIdle(false);
    window.removeEventListener("mousemove", onFadeActivity, { capture: true });
    window.removeEventListener("mousedown", onFadeActivity, { capture: true });
    window.removeEventListener("keydown", onFadeActivity, { capture: true });
    window.removeEventListener("wheel", onFadeActivity, { capture: true });
    window.removeEventListener("touchstart", onFadeActivity, { capture: true });
  }

  function checkAutoFadeConditions() {
    const v = document.querySelector("video");
    const playing = v && !v.paused && !v.ended;
    const shouldRun =
      settings.autoFadeUI &&
      isTheaterMode() &&
      !document.hidden &&
      playing;

    if (shouldRun) {
      startAutoFade();
    } else {
      stopAutoFade();
    }
  }

  function applyAll() {
    setShortsHidden(settings.hideShorts);
    applySpeed();
    buildBar();
    maybeRedirectShorts();
    watchVideo();
    applyLoop();
    maybeLoadSegments();
    renderSegmentBar();
    applyBoost();
    loadDislikes();
    setAdStyle(settings.blockAds);
    handleAds();
    checkAmbientConditions();
    checkAutoFadeConditions();
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      for (const k of Object.keys(changes)) settings[k] = changes[k].newValue;
      // Force a re-fetch of sponsor segments / dislikes when toggles change.
      sbVideoId = null;
      dislikeVid = null;
      applyAll();
    });
  } catch (_) {}

  window.addEventListener("yt-navigate-finish", applyAll, true);
  window.addEventListener("yt-page-data-updated", applyAll, true);
  document.addEventListener("yt-navigate-finish", applyAll, true);

  const mo = new MutationObserver(() => {
    watchVideo();
    applyLoop();
    applyBoost();
    applySpeed();
    // Re-inject the control bar if YouTube rebuilt the page.
    if (location.pathname === "/watch" && !document.getElementById("ct-bar")) {
      buildBar();
    }
    // Re-inject the segment bar if YouTube rebuilt the progress bar.
    if (
      settings.skipSponsors &&
      sbSegments.length &&
      !document.getElementById("ytls-segbar")
    ) {
      renderSegmentBar();
    }
    // Re-inject dislikes if YouTube rebuilt the action bar.
    if (settings.showDislikes && lastDislikes != null) {
      injectDislikes();
    }
    // Re-evaluate theater-mode dependent features (ambient glow, auto-fade)
    // when YouTube's DOM changes (e.g. theater attribute toggled).
    checkAmbientConditions();
    checkAutoFadeConditions();
  });

  function boot() {
    injectPageScript();
    try {
      chrome.storage.local.get({ sbTimeSaved: 0 }, (r) => {
        sbTimeSaved = r.sbTimeSaved || 0;
      });
    } catch (_) {}
    // Pause/resume ambient glow and auto-fade when tab visibility changes.
    document.addEventListener("visibilitychange", () => {
      checkAmbientConditions();
      checkAutoFadeConditions();
    });
    loadSettings(() => {
      applyAll();
      mo.observe(document.documentElement, { childList: true, subtree: true });
      // Fast poll to catch ad skip-buttons and unskippable ads promptly.
      if (!adTimer) adTimer = setInterval(handleAds, 200);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
